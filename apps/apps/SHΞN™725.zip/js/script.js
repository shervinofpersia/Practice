document.addEventListener('DOMContentLoaded', function() {
  console.log('Project mic.html is ready!');
});