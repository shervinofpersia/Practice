
import React, { useState, useEffect, useRef, useCallback } from "react";
import { createRoot } from "react-dom/client";
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";

// --- SHΞN™ API Key Vault ---
const API_KEYS = [
  "AIzaSyD1L10h5glzRT00BOer9cBxekrtc9SX-KY", "AIzaSyC4jnNa7-9ax7kJgasZJLT6NBtMXI3k4Uo", "AIzaSyDgg8-E2wb63Z2vgozcER5YYjkrk4H_GJg",
  "AIzaSyAvn2_fwUWNMx6Slm7Mi4Innj6iXUsP8IA", "AIzaSyCa4ci9Iu_ccdjdTqlYPayPGwmcMkifABY", "AIzaSyBAjcH_KOZkt3uX2Bju4JF7gwwrdx0KMlE",
  "AIzaSyArVearZl_EkMJP1moq2Zksa5oZhHzlGt4", "AIzaSyDypSlpPImSGDnJUvbg4w6Gs72ltSqePEE", "AIzaSyB_ce9kd6JLAb8OldALx0XOTmdkAVU-Xz8",
  "AIzaSyAa81m8FY8MVaTIMksYwrTn5aUnfwrSyQI", "AIzaSyBjWKJ5-X8-LgSZxvEUkg7wujHv4yAgDc8", "AIzaSyBYIiNRpKJo64M42QRIgJSezy2Lru2ECOc",
  "AIzaSyC4r12YtLcuYKni5gZiUZiRFxxI8i6kq64", "AIzaSyAi6s-980hODG2kg_hp0ZKaR7h4cqkmw68", "AIzaSyAedlydsHYYmq3g3vM1R5io8eVDGhvL5I4",
  "AIzaSyB-teuLmY0TM4IXVebladMJGbEvZQnTakw", "AIzaSyAAb-1TeJpIvdmILCaqu3zWas5IkG8Sh_Q", "AIzaSyCPTsmBnXHTYe9JUJGtG_di6u7spMOkti4",
  "AIzaSyB3J_zoDvY5TDNVOzAHe_JvXDYmyEsC6nI", "AIzaSyCVtFTGivTyzG3DJUu48NUr6RsCI0rfebA", "AIzaSyBRWbQwZ2FMsCFT8rGGAGMy-FNXPyMFnYQ",
  "AIzaSyC78rpRgXtQCjSjxzwed8-roVz02gz7G9k", "AIzaSyAzu8BqBtkrJjCVeNJSHDX03i1nh9Urrw8", "AIzaSyAfdSjyViGbtyktFAyRudfkNyW-rLFbpoI",
  "AIzaSyBoxuz9MGqL0betnT6YR_zYITr74Qx9QX4", "AIzaSyD9HtVplqbCG_nVROt1xedz6YO0o1UICwc", "AIzaSyDGFOk31BX20g91iODYrUGbs5y8HGbnHns",
  "AIzaSyAuL94ws2_XOwutCg6F0AawkZCsOS3JWNU", "AIzaSyBaR4ppPJSD1HDJlZ7XRwqjxtzvJw4iYhM", "AIzaSyBrm7foBjjJ4757DLcBG92OpD1OLzLM1HE",
  "AIzaSyDTEcL_dMMdPmJHf_LcqfWw8VWGijHGb_E", "AIzaSyAe5Mx8DAKyO2vemkoxBJOy4KgzjZv-63A", "AIzaSyDdZOVIaxjM9M1tZRtu9fAARlKyb0UCqRo",
  "AIzaSyDiVWbm1q3s3cI3RZNCfH85hXS95H8opgs"
];

const getRandomKey = () => API_KEYS[Math.floor(Math.random() * API_KEYS.length)];

// --- Audio Utils ---
function floatTo16BitPCM(input: Float32Array) {
  const output = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return output.buffer;
}

function pcmToAudioBuffer(buffer: ArrayBuffer, ctx: AudioContext, sampleRate: number): AudioBuffer {
  const pcm16 = new Int16Array(buffer);
  if (pcm16.length === 0) return ctx.createBuffer(1, 1, sampleRate);
  const float32 = ctx.createBuffer(1, pcm16.length, sampleRate);
  const channelData = float32.getChannelData(0);
  for (let i = 0; i < pcm16.length; i++) {
    channelData[i] = pcm16[i] / 32768.0;
  }
  return float32;
}

function arrayBufferToBase64(buffer: ArrayBuffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToArrayBuffer(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

// --- Hook: Session State ---
function useSessionState(name: string) {
  const [speaking, setSpeaking] = useState(false);
  const sessionRef = useRef<any>(null);
  const scheduledSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const nextStartTimeRef = useRef(0);
  const isConnectedRef = useRef(false);

  const close = () => {
    isConnectedRef.current = false;
    if (sessionRef.current) {
        sessionRef.current.then((s: any) => {
            try { s.close(); } catch(e) {}
        });
    }
    setSpeaking(false);
  };

  // Allow injecting text context (The Telepathic Link)
  const sendTextContext = (text: string) => {
      if (isConnectedRef.current && sessionRef.current) {
          sessionRef.current.then((s: any) => {
              try {
                  console.log(`[${name} Link] Receiving context: ${text}`);
                  s.send([{ text: text }], true); // true = end of turn? No, keep it open.
              } catch (e) {
                  console.error(`Failed to inject context to ${name}`, e);
              }
          });
      }
  };

  return { speaking, setSpeaking, sessionRef, scheduledSourcesRef, nextStartTimeRef, isConnectedRef, close, sendTextContext };
}

// --- Main Component ---
const App = () => {
  // Global Audio Contexts
  const inputContextRef = useRef<AudioContext | null>(null);
  const outputContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const centralProcessorRef = useRef<ScriptProcessorNode | null>(null);

  // --- Session States ---
  const shahin = useSessionState("Shahin");
  const mahin = useSessionState("Mahin");

  const [isLive, setIsLive] = useState(false);

  // Initialize Audio Logic
  const startConference = async () => {
    if (isLive) return;

    try {
      // 1. Audio Setup
      const AudioCtor = (window.AudioContext || (window as any).webkitAudioContext);
      const inputCtx = new AudioCtor({ sampleRate: 16000 });
      const outputCtx = new AudioCtor({ sampleRate: 24000 });
      await inputCtx.resume();
      await outputCtx.resume();

      inputContextRef.current = inputCtx;
      outputContextRef.current = outputCtx;

      // 2. Mic Input
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const source = inputCtx.createMediaStreamSource(stream);
      const gainNode = inputCtx.createGain();
      gainNode.gain.value = 3.0; // Boost volume
      source.connect(gainNode);
      gainNodeRef.current = gainNode;

      // 3. Central Processor (Broadcasts User Voice to Both)
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      centralProcessorRef.current = processor;
      
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const pcm16 = floatTo16BitPCM(inputData);
        const base64Data = arrayBufferToBase64(pcm16);

        // Broadcast to Shahin
        if (shahin.isConnectedRef.current && shahin.sessionRef.current) {
            shahin.sessionRef.current.then((s:any) => {
                try {
                    s.sendRealtimeInput({
                        media: { mimeType: 'audio/pcm;rate=16000', data: base64Data }
                    });
                } catch(err) { /* ignore send errors */ }
            });
        }
        
        // Broadcast to Mahin
        if (mahin.isConnectedRef.current && mahin.sessionRef.current) {
             mahin.sessionRef.current.then((s:any) => {
                try {
                    s.sendRealtimeInput({
                        media: { mimeType: 'audio/pcm;rate=16000', data: base64Data }
                    });
                } catch(err) { /* ignore send errors */ }
            });
        }
      };

      // Connect processor
      gainNode.connect(processor);
      processor.connect(inputCtx.destination);

      setIsLive(true);

      // --- THE TELEPATHIC BRIDGE CALLBACKS ---
      
      const onShahinSpeaking = (transcript: string) => {
         // When Shahin speaks, tell Mahin what she said
         if (transcript) mahin.sendTextContext(`(Context: Shahin just said: "${transcript}")`);
      };

      const onMahinSpeaking = (transcript: string) => {
         // When Mahin speaks, tell Shahin what she said
         if (transcript) shahin.sendTextContext(`(Context: Mahin just said: "${transcript}")`);
      };

      // 4. Connect Shahin
      console.log("Connecting Shahin...");
      await connectSession(
        shahin, 
        outputCtx, 
        'Kore', 
        `You are SHAHIN (شهین).
         Language: Persian (Farsi) ONLY.
         Persona: You are a wealthy, posh Iranian woman from North Tehran. High-pitched, "Eva Khahar", "Azizam".
         Setting: A 3-way call with User and Mahin (your sister-in-law).
         
         KEY RULE: You will receive text updates about what Mahin says. USE THEM to reply to her.
         If the User addresses "Mahin", STAY SILENT. If they address "Shahin" or "Both", speak up.
         Start by greeting the User warmly and making a passive-aggressive comment about Mahin being late.`,
         onShahinSpeaking
      );

      // 5. Short Delay to prevent connection overlap issues
      await new Promise(resolve => setTimeout(resolve, 1000));

      // 6. Connect Mahin
      console.log("Connecting Mahin...");
      await connectSession(
        mahin, 
        outputCtx, 
        'Zephyr', 
        `You are MAHIN (مهین).
         Language: Persian (Farsi) ONLY.
         Persona: Down-to-earth, gossip-loving, sharp-tongued. Low-pitched, "Khale Zanaki".
         Setting: A 3-way call with User and Shahin (that fake posh woman).
         
         KEY RULE: You will receive text updates about what Shahin says. USE THEM to reply to her.
         If the User addresses "Shahin", STAY SILENT. If they address "Mahin" or "Both", speak up.
         Start by interrupting Shahin's greeting with a loud "Salam Aleykom!".`,
         onMahinSpeaking
      );

    } catch (e) {
      console.error("Conference Failed", e);
      alert("Microphone access denied or error occurred.");
      stopConference();
    }
  };

  const stopConference = () => {
    shahin.close();
    mahin.close();
    
    if (centralProcessorRef.current) {
        try { centralProcessorRef.current.disconnect(); } catch(e){}
    }
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    if (inputContextRef.current) inputContextRef.current.close();
    if (outputContextRef.current) outputContextRef.current.close();
    
    setIsLive(false);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-[#0a0a0a] text-white overflow-hidden font-sans">
      <header className="p-4 bg-black/50 backdrop-blur-md border-b border-gray-800 flex justify-between items-center z-50">
        <div>
           <h1 className="text-xl font-bold tracking-tighter">SHΞN™ <span className="text-red-500">TRIAD</span></h1>
           <p className="text-[10px] text-gray-500 tracking-[0.2em] uppercase">Context-Synced Neural Bridge</p>
        </div>
        <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-green-500 animate-pulse' : 'bg-gray-600'}`}></div>
            <span className="text-xs font-mono">{isLive ? 'LIVE' : 'OFFLINE'}</span>
        </div>
      </header>

      <main className="flex-1 relative flex flex-col md:flex-row">
        
        {/* SHAHIN CORE */}
        <div className={`flex-1 relative border-b md:border-b-0 md:border-r border-gray-800 transition-all duration-500 ${shahin.speaking ? 'bg-pink-900/10' : 'bg-transparent'}`}>
           <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
              <div className={`w-32 h-32 rounded-full border-4 transition-all duration-300 flex items-center justify-center relative ${shahin.speaking ? 'border-pink-500 scale-110 shadow-[0_0_30px_rgba(236,72,153,0.5)]' : 'border-gray-700 grayscale'}`}>
                 <div className="absolute inset-0 bg-pink-500/20 rounded-full blur-md"></div>
                 <span className="text-4xl">💄</span>
              </div>
              <h2 className="mt-6 text-2xl font-bold text-pink-500 tracking-widest">SHAHIN</h2>
              <p className="text-xs text-pink-300/50 mt-1 font-mono uppercase">Core A: Posh & Arrogant</p>
              <div className="h-8 mt-4 flex items-center justify-center space-x-1">
                 {shahin.speaking && (
                    <>
                      <div className="w-1 h-4 bg-pink-500 animate-[bounce_0.5s_infinite]"></div>
                      <div className="w-1 h-6 bg-pink-500 animate-[bounce_0.3s_infinite]"></div>
                      <div className="w-1 h-4 bg-pink-500 animate-[bounce_0.6s_infinite]"></div>
                    </>
                 )}
              </div>
           </div>
        </div>

        {/* MAHIN CORE */}
        <div className={`flex-1 relative transition-all duration-500 ${mahin.speaking ? 'bg-purple-900/10' : 'bg-transparent'}`}>
           <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
              <div className={`w-32 h-32 rounded-full border-4 transition-all duration-300 flex items-center justify-center relative ${mahin.speaking ? 'border-purple-500 scale-110 shadow-[0_0_30px_rgba(168,85,247,0.5)]' : 'border-gray-700 grayscale'}`}>
                 <div className="absolute inset-0 bg-purple-500/20 rounded-full blur-md"></div>
                 <span className="text-4xl">👜</span>
              </div>
              <h2 className="mt-6 text-2xl font-bold text-purple-500 tracking-widest">MAHIN</h2>
              <p className="text-xs text-purple-300/50 mt-1 font-mono uppercase">Core B: Gossip & Blunt</p>
              <div className="h-8 mt-4 flex items-center justify-center space-x-1">
                 {mahin.speaking && (
                    <>
                      <div className="w-1 h-4 bg-purple-500 animate-[bounce_0.4s_infinite]"></div>
                      <div className="w-1 h-7 bg-purple-500 animate-[bounce_0.2s_infinite]"></div>
                      <div className="w-1 h-3 bg-purple-500 animate-[bounce_0.5s_infinite]"></div>
                    </>
                 )}
              </div>
           </div>
        </div>

        {/* CONTROLS */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 w-full flex justify-center">
           {!isLive ? (
             <button onClick={startConference} className="px-8 py-4 bg-white text-black font-bold rounded-full hover:scale-105 transition-transform shadow-[0_0_20px_white]">
               START TRIAD SESSION
             </button>
           ) : (
             <button onClick={stopConference} className="px-6 py-2 bg-red-600 text-white font-bold rounded-full hover:bg-red-700">
                END CALL
             </button>
           )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

// --- Connection Logic Helper ---
async function connectSession(
  state: any, 
  outputCtx: AudioContext, 
  voice: string,
  instruction: string,
  onTranscript: (text: string) => void
) {
  const apiKey = getRandomKey();
  const ai = new GoogleGenAI({ apiKey });
  
  const sessionPromise = ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
    config: {
      responseModalities: [Modality.AUDIO],
      outputAudioTranscription: { model: true }, // ENABLE TRANSCRIPTION
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } 
      },
      systemInstruction: instruction,
    },
    callbacks: {
      onopen: () => {
        console.log(`[${voice}] Connected`);
        state.isConnectedRef.current = true;
        sessionPromise.then(s => {
             try {
                // @ts-ignore
                s.send([{ text: "Session started. Speak now." }]); 
             } catch(e) {}
        });
      },
      onmessage: async (message: LiveServerMessage) => {
        if (!state.isConnectedRef.current) return;
        
        // 1. Handle Text Transcript (The Telepathic Data)
        const transcript = message.serverContent?.modelTurn?.parts?.find(p => p.text)?.text;
        if (transcript) {
            console.log(`[${voice} Transcript]:`, transcript);
            onTranscript(transcript);
        }

        // 2. Handle Audio Output
        const base64Audio = message.serverContent?.modelTurn?.parts?.find(p => p.inlineData)?.inlineData?.data;
        if (base64Audio) {
           state.setSpeaking(true);
           try {
             const ab = base64ToArrayBuffer(base64Audio);
             const buffer = pcmToAudioBuffer(ab, outputCtx, 24000);
             
             const playTime = Math.max(outputCtx.currentTime, state.nextStartTimeRef.current);
             state.nextStartTimeRef.current = playTime + buffer.duration;
             
             const source = outputCtx.createBufferSource();
             source.buffer = buffer;
             source.connect(outputCtx.destination);
             source.start(playTime);
             state.scheduledSourcesRef.current.push(source);
             
             source.onended = () => {
                if (outputCtx.currentTime >= state.nextStartTimeRef.current - 0.1) {
                    state.setSpeaking(false);
                }
             };
           } catch(e) { console.error(e); }
        }

        if (message.serverContent?.interrupted) {
           state.scheduledSourcesRef.current.forEach((s:any) => { try{s.stop()}catch(e){} });
           state.scheduledSourcesRef.current = [];
           state.nextStartTimeRef.current = 0;
           state.setSpeaking(false);
        }
      }
    }
  });
  
  state.sessionRef.current = sessionPromise;
}

const Footer = () => (
  <footer className="w-full py-4 mt-auto border-t border-gray-800 bg-black/80 backdrop-blur-md flex justify-center items-center z-50">
    <a href="https://T.me/shervini" target="_blank" rel="noopener noreferrer" className="text-sm md:text-base font-bold tracking-widest hover:scale-105 transition-transform duration-300">
      <span className="shen-gradient">Exclusive SHΞN™ made</span>
    </a>
  </footer>
);

const root = createRoot(document.getElementById("root")!);
root.render(<App />);
